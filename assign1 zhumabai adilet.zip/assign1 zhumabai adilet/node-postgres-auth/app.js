const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');
const { Pool } = require('pg');

const app = express();
const port = 3000;

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'assign1',
  password: 'maimir2005',
  port: 5432,
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'secret_key', resave: true, saveUninitialized: true }));

// Registration form
app.get('/register', (req, res) => {
  res.sendFile(__dirname + '/register.html');
});

// Update the '/register' route handler in your Express app
app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    const result = await pool.query('INSERT INTO users (username, password) VALUES ($1, $2) RETURNING id', [username, hashedPassword]);
    console.log('User registered with ID:', result.rows[0].id);
    res.redirect('/login');
  } catch (error) {
    console.error('Error registering user:', error);
    // Redirect to /register with an error parameter
    res.redirect('/register?error=true');
  }
});


// Login form
app.get('/login', (req, res) => {
  res.sendFile(__dirname + '/login.html');
});

// Update the '/login' route handler in your Express app
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const result = await pool.query('SELECT * FROM users WHERE username = $1', [username]);

    if (result.rows.length > 0) {
      const match = await bcrypt.compare(password, result.rows[0].password);
      if (match) {
        req.session.userId = result.rows[0].id;
        res.redirect('/dashboard');
      } else {
        // Redirect to /login with an error parameter
        res.redirect('/login?error=true');
      }
    } else {
      // Redirect to /login with an error parameter
      res.redirect('/login?error=true');
    }
  } catch (error) {
    console.error('Error logging in:', error);
    // Redirect to /login with an error parameter
    res.redirect('/login?error=true');
  }
});


// Dashboard (after successful login)
app.get('/dashboard', (req, res) => {
  if (req.session.userId) {
    res.send('Welcome to the dashboard!');
  } else {
    res.redirect('/login');
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
